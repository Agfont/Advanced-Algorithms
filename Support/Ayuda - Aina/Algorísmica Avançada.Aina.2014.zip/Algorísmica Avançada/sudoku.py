def parse_sudoku(nombre_fichero):
    matriz = [[0]*9 for v in range(10)]
    fichero = open(nombre_fichero, "r")
    
    lineas_fichero = fichero.readlines()
    
    for line in range(0, len(lineas_fichero)):
        for elem in range (0, len(lineas_fichero)):
            if lineas_fichero[line][elem] != "\n" and  lineas_fichero[line][elem] != ".":
                matriz[line][elem] = int(lineas_fichero[line][elem])
            
            
            
    print matriz
    return matriz


def satisfact(sudoku):
    #matriz_cuadrados = [[[[0]*3 for x in range(4)] for v in range (4)] for y in range (4)] 
    
        
    for i in range(0,len(sudoku)-1):
        print "indice i", i
        auxFila = []
        auxColumna = []
        
        for j in range(0,len(sudoku)-1):
            
            print "indice j", j
            print "lista filas", auxFila
            print "lista columnas", auxColumna

            if (sudoku[i][j] > 0  and sudoku[i][j] <= 9 and sudoku[i][j] not in auxFila) or (sudoku[i][j] == 0):
                if (sudoku[j][i] > 0 and sudoku[j][i] <= 9 and sudoku[j][i] not in auxColumna) or (sudoku[j][i] == 0):
                    auxFila.append(sudoku[i][j])
                    auxColumna.append(sudoku[j][i])
            else:
                print "Nooouuuuuup :("
                return
    
    print "success :D"
       
       
satisfact(parse_sudoku("sudoku.txt"))



#[[[000, 000, 000], [000, 000, 000], [000, 000, 000]], [[000, 000, 000], [000, 000, 000], [000, 000, 000]], [[000, 000, 000], [000, 000, 000], [000, 000, 000]]] 