import time

'''
Parser function.
Transforms a file with numbers and points into a sudoku.
Notice that this function excepts a determinated type of file.
If the file is corrupt, it will return an error
Complexity is O(n) being n = number of boxes (aka 81 boxes in a 9x9 sudoku)
Commonly, we will write O(n^2) being n = number of cols/rows (9 cols/rows => 9x9 sudoku => 81 boxes).

Notice that this is thought for a 9x9 sudoku.
Can be changed for a nxn sudoku by changing the numbers of the matrix for the length of the firs line (for example).
'''
def parse_sudoku(fileName):
    matrix = [[0]*9 for v in range(9)]
    fi = open(fileName, "r")
    
    lines = fi.readlines()
    for line in range(9):
        for elem in range (9):
            if lines[line][elem] != "\n" and  lines[line][elem] != ".":
                matrix[line][elem] = int(lines[line][elem])     
            

    return matrix

'''
Satisfact function.
Checks if the sudoku can be solved.
Complexity is O(n^2), as said before, being n = number of cols/rows.

Notice again that this is thought for an 9x9 sudoku, it makes de code simplier and cleaner.
Can be easily generalized to a nxn sudoku by reading the length of the first row, for example.
First loops should be len(m[0]), and second loops should be range (0, len(m[0]), sqrt(len(m[0]))).
'''
def satisfact(m):
    #We will put every number in the row /in the col in a list.
    #For every col/row we will check if numbers are repeated. 
    for i in range (9):
        auxRows = []
        auxCols = []
        for j in range(9):
            if (m[i][j] == 0 or m[i][j] not in auxRows) and (m[j][i] == 0 or m[j][i] not in auxCols):
                auxRows.append(m[i][j])
                auxCols.append(m[j][i])
            else:
                return False
            
    
    #Blocks works the same way.
    #But we need to go steps of 3 on 3.
    for v in range(0, 9, 3):
        auxBlocks = []
        for k in range(3):
            if (m[v][k] == 0 or m[v][k] not in auxBlocks) and (m[v+1][k] == 0 or m[v+1][k] not in auxBlocks) and (m[v+2][k] == 0 or m[v+2][k] not in auxBlocks):
                auxBlocks.append(m[v][k])
                auxBlocks.append(m[v+1][k])
                auxBlocks.append(m[v+2][k])
            else:
                return False
            
    return True


#--------------------------------------BRUTE FORCE----------------------------

'''
First algorythm will check every possible solution.
This means: without heuristic.
Poorly optimized
'''
def solveBruteForce(m):
    #If the sudoku is valid, proceed to solve:
    if satisfact(m) == True:
        print "Solving sudoku"
        #We need to find where to start to.
        #Notice here the ugly checking: if the sudoku is already full, we don't have to anything.
        #This is  very small optimization. 
        i, j = findGap(m)
        if i != -1 and j != -1:
            #Remember that this is brute force, we need to go through every possibility:
            t0 = time.clock()
            for k in range(1, 10):
                fillSudokuBruteForce(m, i, j, k)
            t1 = time.clock()
            print m
            print "Time used %0.3f ms" %((t1-t0)*1000)
        else:
            print "Sudoku was already solved"
    else:
        print "Initial sudoku is incorrect"

#This will be our recursive function to fill the sudoku.
def fillSudokuBruteForce(m, i, j, t):
    print m
    #If the box is full, we don't have to change it. At least not here. 
    if m[i][j] != 0:
        
        #Look up for the next empty box
        i, j = findGap(m)
        #If there's an empty box:
        if i != -1 and j != -1:
            #try to fill it!
            for v in range (1, 10):
                fillSudokuBruteForce(m, i, j, v)
        #If there isn't any empty boxes, then sudoku is done.        
        else:
            return
    #We can fill this box, first fill it and then look up for the next one:   
    else:
        m[i][j] = t
        
        #Now we must check if this solution is viable.
        #If not, this means we have to go back and change previous given solution.
        if satisfact(m):
            #If the solution is valid, go on.
            i, j = findGap(m)
            
            #Can we find more empty boxes?
            if i != -1 and j != -1:
                for v in range (1, 10):
                    fillSudokuBruteForce(m, i, j, v)
            else:
                #No more boxes to fill
                return
        else:
            #solution is not valid, put the box again to 0
            m[i][j] = 0
            return
    
    
#Finding empty boxes in our sudoku.       
def findGap(m):
    for i in range (9):
        for j in range (9):
            if m[i][j] == 0:
                return i, j
    #This is for an ugly checking.
    #If the sudoku is already full, then we don't have to do anything else.
    #We will flag this using -1 as a value in our indexes.         
    i , j = -1, -1
    return i, j


solveBruteForce((parse_sudoku("sudoku2.txt")))


#--------------------------------HEURISTIC SUDOKU-----------------------





